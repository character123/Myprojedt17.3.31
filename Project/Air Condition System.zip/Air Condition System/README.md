# AirConditionSystem

This project simulates a center controller of an Air Conditioning System.

Written by Hong Zhilong at BUPT in 2016.6

#ifndef STRATEGY_H
#define STRATEGY_H

enum Strategy{
    FIFS, HP, RR
};
// First In First Served, High Speed Wind Priority, Round Robin

#endif // STRATEGY_H

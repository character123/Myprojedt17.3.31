#ifndef WIND_H
#define WIND_H

enum Wind{
    stop, low, medium, high
};

#endif // WIND_H

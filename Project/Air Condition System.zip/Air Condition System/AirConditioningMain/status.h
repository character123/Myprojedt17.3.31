#ifndef STATUS_H
#define STATUS_H

enum ConnectionStatus{
    connected, disconnected, lostconnect
};

#endif // STATUS_H

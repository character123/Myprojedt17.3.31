#ifndef WORKMODE
#define WORKMODE

enum WorkMode{
    Cold,Hot
};

#endif // WORKMODE

